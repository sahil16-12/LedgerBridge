package com.codewithus.ledgerbridge.Dto;

public enum OtpStatus {

    DELIVERED,FAILED
}
