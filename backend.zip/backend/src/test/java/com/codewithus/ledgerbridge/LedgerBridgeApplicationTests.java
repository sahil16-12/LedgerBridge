package com.codewithus.ledgerbridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LedgerBridgeApplicationTests {

    @Test
    void contextLoads() {
    }

}
